import React from "react";
import styled from "@mui/styled-engine-sc";
import { Box } from "@mui/material";
import Carousel from "fade-carousel";

const arr = [
  "images/Partners/Partners-01.png",
  "images/Partners/Partners-02.png",
  "images/Partners/Partners-03.png",
  "images/Partners/Partners-04.png",
  "images/Partners/Partners-05.png",
  "images/Partners/Partners-06.png",
  "images/Partners/Partners-07.png",
  "images/Partners/Partners-08.png",
  "images/Partners/Partners-09.png",
  "images/Partners/Partners-10.png",
  "images/Partners/Partners-11.png",
];
const Partners: React.FC<any> = () => {
  return (
    <StyledContainer>
      <video src="videos/Stars_Partners.webm" autoPlay muted loop />
      <Box>
        <img src="images/Earth_Partners.png" alt="" />
        <Pictures>
          <Carousel delay={3000} mode="fade" divStyle={{ height: 300 }}>
            {arr.map((url, i) => (
              <img key={i} src={url} alt="asdada" />
            ))}
          </Carousel>
          <TitleMobile>Partners</TitleMobile>
        </Pictures>
      </Box>
      <Title>Partners</Title>
    </StyledContainer>
  );
};

const Pictures = styled(Box)`
  position: absolute;
  top: 15%;
  right: 535px;
  width: 260px;
  > div > div {
    overflow: unset !important;
    display: flex;
    align-items: center;
    > div:not(:last-of-type) {
      height: auto !important;
      justify-content: center;
    }
    > div:last-of-type > div {
      display: flex;
      align-items: center;
      align-self: unset;
    }
  }
  svg:first-of-type {
    transform: translateX(-100px);
    stroke: white;
  }
  svg:nth-of-type(2) {
    transform: translateX(100px);
    stroke: white;
  }
  @media (max-width: 1000px) {
    right: 435px;
  }
  @media (max-width: 800px) {
    right: 285px;
  }
  @media (max-width: 768px) {
    top: unset;
    bottom: 50%;
    svg {
      display: none;
    }
  }
  @media (max-width: 600px) {
    right: 75px;
  }
  @media (width: 2312px) and (height: 1080px) {
    right: 670px;
  }
  @media (width: 912px) and (height: 1368px) {
    right: 530px;
  }
  @media (width: 540px) and (height: 720px) {
    top: 41%;
    right: 75px;
  }
  @media (width: 768px) and (height: 1024px) {
    top: unset;
    right: 285px;
  }
  @media (width: 1024px) and (height: 600px) {
    top: 25%;
    right: 530px;
  }
  @media (width: 1280px) and (height: 800px) {
    top: 15%;
    right: 535px;
  }
  @media (width: 375px) and (height: 667px) {
    top: 40%;
  }
`;

const Title = styled(Box)`
  position: absolute;
  top: 46%;
  left: 159.06px;
  transform: translateY(-50%);
  font-weight: 600;
  font-size: 65px;
  line-height: 79px;
  letter-spacing: -0.05em;
  color: white;
  @media (max-width: 1400px) {
    display: none;
  }
`;

const TitleMobile = styled(Box)`
  position: absolute;
  bottom: calc(100% + 30px);
  left: 50%;
  transform: translateX(-50%);
  font-weight: 600;
  font-size: 45px;
  line-height: 55px;
  letter-spacing: -0.05em;
  color: #ffffff;
  @media (min-width: 1401px) {
    display: none;
  }
  @media (width: 390px) and (height: 844px) {
    left: 85%;
  }
`;

const StyledContainer = styled(Box)`
  position: relative;
  height: 100vh;
  background: url("images/Sky.png") no-repeat;
  background-size: cover;
  > div:first-of-type {
    position: absolute;
    width: 100%;
    bottom: 0;
    left: 0;
    display: flex;
    justify-content: flex-end;
    > img {
      max-width: unset;
      height: 100%;
      @media (min-width: 1920px) {
        width: 100%;
      }
      @media (max-width: 1000px) {
        object-position: 100px;
      }
      @media (max-width: 800px) {
        object-position: 250px;
      }
      @media (max-width: 600px) {
        object-position: 460px;
      }
      @media (width: 912px) and (height: 1368px) {
        height: 935px;
      }
      @media (width: 412px) and (height: 914px) {
        object-position: 460px;
      }
    }
  }
  > video:first-of-type {
    position: absolute;
    width: 100%;
    height: 100%;
  }
`;

export default Partners;
