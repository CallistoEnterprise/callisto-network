import React from 'react'
import styled from '@mui/styled-engine-sc'
import { Box } from '@mui/material'

const Sidebar: React.FC = () => {
    return (
        <StyledContainer>
            
        </StyledContainer>
    );
}

const StyledContainer = styled(Box)`
`

export default Sidebar;