declare module '*.woff';
declare module '*.woff2';
declare module '*.ttf';
declare module '*.otf';
declare module 'fade-carousel';
declare module 'body-scroll-lock';